import Link from "next/link";

export default function Footer() {
    return (
        <>
        <div className="flex h-24 w-full items-center justify-center border-t">
            <p>Powered by <Link href="https://github.com/akshaynstack" target="_blank">VasarAI</Link></p>
        </div>
        </>
    );
}