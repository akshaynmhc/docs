import AuthPage from '@/components/auth/AuthPage'

export default function Page() {
  return <AuthPage />
} 