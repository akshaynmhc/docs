// 'use client';

// import { useState } from 'react';

// const Home = () => {
//   const [prompt, setPrompt] = useState('');
//   const [image, setImage] = useState<string | null>(null);
//   const [error, setError] = useState('');
//   const [isLoading, setIsLoading] = useState(false);

//   const handleGenerateImage = async () => {
//     if (!prompt) {
//       setError('Prompt cannot be empty!');
//       return;
//     }

//     setIsLoading(true);
//     setError('');

//     try {
//       const response = await fetch('/api/generate', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ prompt }),
//       });

//       if (!response.ok) {
//         throw new Error('Failed to generate image');
//       }

//       const data = await response.json();
//       setImage(`data:image/jpeg;base64,${data.base64}`);
//     } catch (error) {
//       setError((error as Error).message);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div style={{ padding: '20px' }}>
//       <h1>Image Generator</h1>
//       <input
//         type="text"
//         value={prompt}
//         onChange={(e) => setPrompt(e.target.value)}
//         placeholder="Enter a prompt"
//         style={{ width: '300px', marginRight: '10px' }}
//       />
//       <button onClick={handleGenerateImage} disabled={isLoading}>
//         {isLoading ? 'Generating...' : 'Generate Image'}
//       </button>
//       {error && <p style={{ color: 'red' }}>{error}</p>}
//       {image && <img src={image} alt="Generated" style={{ marginTop: '20px', maxWidth: '100%' }} />}
//     </div>
//   );
// };

// export default Home;

'use client';

// src/app/page.tsx
import { useState, useEffect } from 'react';

const Home = () => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [timer, setTimer] = useState(0); // Timer state

  const handleGenerateImage = async () => {
    if (!prompt) {
      setError('Prompt cannot be empty!');
      return;
    }

    setIsLoading(true);
    setError('');
    setTimer(0); // Reset timer when starting generation

    // Start timer
    const timerInterval = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate image');
      }

      const data = await response.json();
      setImage(`data:image/jpeg;base64,${data.base64}`);
    } catch (error) {
      setError((error as Error).message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
      clearInterval(timerInterval); // Clear timer when done
    }
  };

  // Cleanup timer on component unmount
  useEffect(() => {
    return () => {
      setTimer(0); // Reset timer when component unmounts
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4">AI Image Generator</h1>
      <input
        type="text"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Enter a prompt"
        className="border border-gray-300 rounded-lg p-2 mb-4 w-full max-w-md"
      />
      <button
        onClick={handleGenerateImage}
        disabled={isLoading}
        className={`bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg transition duration-300 ${
          isLoading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'
        }`}
      >
        {isLoading ? (
          <span className="flex items-center">
            <svg
              className="animate-spin h-5 w-5 mr-3"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 0114.32-3.64l-1.5 1.5A6.5 6.5 0 006.5 12H4z"
              />
            </svg>
            Generating... {timer} seconds
          </span>
        ) : (
          'Generate Image'
        )}
      </button>
      {timer && <p className="text-gray-600 mt-2">Time elapsed: {timer} seconds</p>}
      {error && <p className="text-red-500 mt-4">{error}</p>}
      {image && (
        <div className="mt-4">
          <img src={image} alt="Generated" className="max-w-full rounded-lg shadow-lg" />
        </div>
      )}
    </div>
  );
};

export default Home;
