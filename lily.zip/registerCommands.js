import { REST } from 'discord.js';
import { Routes } from 'discord-api-types/v9';
import dotenv from 'dotenv';

dotenv.config();

const commands = [
    {
        name: 'lily',
        description: 'Generate an image based on your prompt and selected model.',
        options: [
            {
                type: 3, // 3 is the type for STRING
                name: 'prompt',
                description: 'Enter your prompt',
                required: true,
            },
            {
                type: 3, // 3 is the type for STRING
                name: 'model',
                description: 'Select a model',
                required: true,
                choices: availableModels.map(model => ({
                    name: model,
                    value: model,
                })),
            },
        ],
    },
];

const rest = new REST({ version: '9' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {
            body: commands,
        });

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error registering commands:', error);
    }
})();