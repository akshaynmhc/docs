import { Client, GatewayIntentBits, Events, REST } from 'discord.js';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import { Routes } from 'discord-api-types/v9';

dotenv.config();

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

// Your Discord bot token and API key
const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const API_KEY = process.env.API_KEY; // Store your API key in a .env file
const CLIENT_ID = process.env.CLIENT_ID; // Your bot's client ID

// List of available models
const availableModels = [
    'Flux Schnell',
    'Flux Dev',
    'Flux Pro',
    'Flux Pro Ultra',
    'Flux Pro Ultra Raw',
    'flux-pixel',
    'flux-realism'
];

// Register the slash command
const registerCommands = async () => {
    const commands = [
        {
            name: 'lily',
            description: 'Generate an image based on your prompt and selected model.',
            options: [
                {
                    type: 3, // 3 is the type for STRING
                    name: 'prompt',
                    description: 'Enter your prompt',
                    required: true,
                },
                {
                    type: 3, // 3 is the type for STRING
                    name: 'model',
                    description: 'Select a model',
                    required: true,
                    choices: availableModels.map(model => ({
                        name: model,
                        value: model,
                    })),
                },
            ],
        },
    ];

    const rest = new REST({ version: '9' }).setToken(DISCORD_TOKEN);

    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(Routes.applicationCommands(CLIENT_ID), {
            body: commands,
        });

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error registering commands:', error);
    }
};

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    await registerCommands(); // Register commands when the bot is ready
});

// Handle interactions
client.on(Events.InteractionCreate, async interaction => {
    if (interaction.isCommand() && interaction.commandName === 'lily') {
        await interaction.deferReply(); // Acknowledge the interaction

        const prompt = interaction.options.getString('prompt');
        const modelName = interaction.options.getString('model');

        // Generate the image
        try {
            const response = await fetch('https://cablyai.com/v1/images/generations', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${API_KEY}`
                },
                body: JSON.stringify({
                    model: modelName,
                    prompt: prompt,
                    n: 1,
                    size: '1024x1024'
                })
            });

            if (!response.ok) {
                throw new Error('Failed to generate image');
            }

            const data = await response.json();
            const imageUrl = data.data[0]?.url;

            if (!imageUrl) {
                throw new Error('Image URL not found in response');
            }

            await interaction.editReply(imageUrl); // Edit the reply with the image URL
        } catch (error) {
            console.error('Error:', error);
            await interaction.editReply('Failed to generate image. Please check your API key and try again.');
        }
    }
});

// Login to Discord
client.login(DISCORD_TOKEN);